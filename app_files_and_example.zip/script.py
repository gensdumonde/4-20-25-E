import os
import json
import boto3

def main():
    secret_arn = os.environ.get("APP_CREDENTIALS_SECRET_ARN")
    if not secret_arn:
        print("Error: APP_CREDENTIALS_SECRET_ARN not set")
        return

    region = os.environ.get("AWS_REGION")
    client = boto3.client("secretsmanager", region_name=region)

    response = client.get_secret_value(SecretId=secret_arn)
    secret = json.loads(response["SecretString"])

    for key, value in secret.items():
        print(f"{key}: {value}")

if __name__ == "__main__":
    main()