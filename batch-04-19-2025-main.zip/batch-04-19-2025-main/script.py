import os
import json
import requests
import boto3
import logging
import sys

logging.basicConfig(stream=sys.stdout, level=logging.INFO)

def main():
    # Retrieve env vars (injected via AWS Batch job definition)
    api_user   = os.getenv("API_USER")
    api_pass   = os.getenv("API_PASS")
    api_url    = os.getenv("API_URL")
    api_port   = os.getenv("API_PORT")
    s3_bucket  = os.getenv("S3_BUCKET")

    if not all([api_user, api_pass, api_url, api_port, s3_bucket]):
        logging.error("Missing one or more required environment variables.")
        sys.exit(1)

    endpoint = f"{api_url}:{api_port}"
    logging.info(f"Calling API at {endpoint}")

    try:
        resp   = requests.get(endpoint, auth=(api_user, api_pass))
        resp.raise_for_status()
        result = resp.json()
    except Exception as e:
        logging.error(f"API request failed: {e}")
        sys.exit(1)

    # Upload result to S3
    s3  = boto3.client("s3")
    key = f"batch_results/{os.getenv('AWS_BATCH_JOB_ID','job')}.json"
    body = json.dumps(result)

    try:
        s3.put_object(Bucket=s3_bucket, Key=key, Body=body)
        logging.info(f"Uploaded result to s3://{s3_bucket}/{key}")
    except Exception as e:
        logging.error(f"S3 upload failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
